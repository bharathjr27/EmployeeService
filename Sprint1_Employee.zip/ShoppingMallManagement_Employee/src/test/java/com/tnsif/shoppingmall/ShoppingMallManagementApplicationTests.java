package com.tnsif.shoppingmall;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingMallManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
